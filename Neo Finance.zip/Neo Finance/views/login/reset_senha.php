<?php
session_start();
require '../../vendor/autoload.php';

include '../../config/database/conexao.php'; // conexão com o banco de dados


if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['reset_email'])) {
        die("Sessão de redefinição de senha não encontrada.");
    }

    $email = $_SESSION['reset_email'];
    $newPassword = $_POST['new-password'];
    $confirmNewPassword = $_POST['confirm-new-password'];

    // Verificar se as senhas coincidem
    if ($newPassword !== $confirmNewPassword) {
        $_SESSION['error'] = 'As senhas não coincidem!';
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    }

    // Hash da nova senha
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Atualizar a senha no banco de dados
    $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
    $stmt->bind_param("ss", $hashedPassword, $email);

    if (!$stmt->execute()) {
        die("Erro ao atualizar a senha: " . $stmt->error);
    }

    // Verificar se a senha foi atualizada
    if ($stmt->affected_rows === 0) {
        die("Nenhuma linha foi atualizada. Verifique se o email está correto.");
    }

    // Obter o ID do usuário usando o email fornecido
    $user_query = "SELECT id FROM users WHERE email = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bind_param("s", $email);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();

    if ($user_result->num_rows === 0) {
        die("Usuário não encontrado");
    }

    $user_id = $user_result->fetch_assoc()['id'];

    // Remover o código de redefinição do banco de dados
    $delete_query = "DELETE FROM password_resets WHERE user_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $user_id);

    if (!$delete_stmt->execute()) {
        die("Erro ao remover o código de redefinição: " . $delete_stmt->error);
    }

    // Fechar statements e conexão
    $stmt->close();
    $user_stmt->close();
    $delete_stmt->close();
    $conn->close();

    // Limpar a variável de sessão e redirecionar para a tela de login
    unset($_SESSION['reset_email']);
    header("Location: ./login.php");
    exit();
}

// Exibir mensagem de erro se existir
if (isset($_SESSION['error'])) {
    $errorMessage = $_SESSION['error'];
    unset($_SESSION['error']);
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/telaLogin.css">
</head>
<?php if (!empty($errorMessage)): ?>
    <div class="message error">
        <?php echo htmlspecialchars($errorMessage); ?>
    </div>
<?php endif; ?>

<body>
    <div class="main-container">
        <div class="form-wrapper">
            <div class="primary-section">
                <div class="about-section">
                    <p class="greet">Bem-vindo a</p>
                    <div class="logo">
                        <img src="./assets/NeoFinance--Logo.svg" alt="NeoFinance--Logo">
                        <p>Neo Finance</p>
                    </div>
                    <p class="about"></p>
                    <div class="pages-link">
                        <a href="#" id="open-privacy-modal" style="color: #fff; text-decoration: none;">Política de privacidade</a>
                    </div>
                </div>
            </div>
            <div class="secondary-section">
                <h2 id="form-title">Redefinir Senha</h2>
                <form id="reset-password-form" method="post" action="./reset_senha.php">
                    <div class="input-field">
                        <label for="new-password">Nova Senha</label>
                        <input type="password" id="new-password" name="new-password" placeholder="Insira a nova senha" required>
                    </div>
                    <div class="input-field">
                        <label for="confirm-new-password">Confirmar Nova Senha</label>
                        <input type="password" id="confirm-new-password" name="confirm-new-password" placeholder="Confirme a nova senha" required>
                    </div>
                    <div class="button-sec">
                        <button type="submit" class="reset-password-btn">Redefinir Senha</button>
                    </div>
                    <div class="back-to-login">
                        <p><a href="./login.php">Voltar para Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="privacy-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Política de Privacidade</h2>
            <p><strong>1. Introdução</strong></p>
            <p>Bem-vindo à [Neo Finance]. A sua privacidade é importante para nós. Esta Política de Privacidade explica como coletamos, usamos, armazenamos e protegemos suas informações pessoais quando você usa nosso site e serviços. Ao acessar ou usar nosso site, você concorda com a coleta e uso de informações conforme descrito nesta política.</p>

            <p><strong>2. Informações que Coletamos</strong></p>
            <p><strong>2.1 Informações Pessoais:</strong> Coletamos informações pessoais que você nos fornece diretamente, como nome, e-mail e informações financeiras necessárias para o uso de nossos serviços.</p>
            <p><strong>2.2 Informações de Uso:</strong> Coletamos informações sobre sua interação com nosso site, como endereço IP, tipo de navegador, páginas visitadas e tempo gasto em cada página.</p>
            <p><strong>2.3 Cookies e Tecnologias Semelhantes:</strong> Utilizamos cookies e outras tecnologias semelhantes para melhorar sua experiência no site, analisar o tráfego e personalizar o conteúdo. Você pode ajustar as configurações de cookies em seu navegador a qualquer momento.</p>

            <p><strong>3. Uso das Informações</strong></p>
            <p><strong>3.1 Fornecimento de Serviços:</strong> Usamos suas informações pessoais para fornecer, manter e melhorar nossos serviços, incluindo o processamento de transações e a personalização de sua experiência.</p>
            <p><strong>3.2 Comunicação:</strong> Podemos usar suas informações para entrar em contato com você sobre atualizações, ofertas promocionais e outras informações relevantes. Você pode optar por não receber essas comunicações a qualquer momento.</p>
            <p><strong>3.3 Análise e Melhoria:</strong> Utilizamos informações de uso para analisar o desempenho do site e melhorar nossos serviços.</p>

            <p><strong>4. Compartilhamento de Informações</strong></p>
            <p><strong>4.1 Terceiros:</strong> Não compartilhamos suas informações pessoais com terceiros, exceto quando necessário para cumprir a lei, proteger nossos direitos ou fornecer nossos serviços.</p>
            <p><strong>4.2 Segurança:</strong> Adotamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não autorizado, alteração ou destruição.</p>

            <p><strong>5. Seus Direitos</strong></p>
            <p><strong>5.1 Acesso e Correção:</strong> Você tem o direito de acessar, corrigir ou excluir suas informações pessoais que mantemos. Para fazer isso, entre em contato conosco através das informações fornecidas abaixo.</p>
            <p><strong>5.2 Opt-Out:</strong> Você pode optar por não receber comunicações promocionais a qualquer momento, seguindo as instruções de cancelamento de inscrição incluídas em nossos e-mails.</p>

            <p><strong>6. Alterações nesta Política</strong></p>
            <p>Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre qualquer alteração significativa por meio de uma postagem em nosso site ou por e-mail. Recomendamos que você reveja esta política regularmente para se manter informado sobre como protegemos suas informações.</p>

            <p><strong>7. Contato</strong></p>
            <p>Se você tiver dúvidas sobre esta Política de Privacidade ou sobre nossas práticas de privacidade, entre em contato conosco:</p>
            <p>E-mail: [Seu e-mail]</p>
            <p>Endereço: [Seu endereço]</p>
            <p>Telefone: [Seu telefone]</p>
        </div>
    </div>

    <script>
        var modal = document.getElementById('privacy-modal');
        var openModalLink = document.getElementById('open-privacy-modal');
        var closeButton = document.getElementsByClassName('close')[0];

        openModalLink.onclick = function() {
            modal.style.display = 'block';
        }

        closeButton.onclick = function() {
            modal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>

</html>