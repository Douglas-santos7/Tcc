<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../../css/login/telaLogin.css">
</head>

<body>
    <?php
    if (isset($_SESSION['signup_message'])) {
        echo '<div class="message">' . htmlspecialchars($_SESSION['signup_message']) . '</div>';
        unset($_SESSION['signup_message']);
    }

    if (isset($_SESSION['login_message'])) {
        echo '<div class="message">' . htmlspecialchars($_SESSION['login_message']) . '</div>';
        unset($_SESSION['login_message']);
    }

    if (isset($_SESSION['reset_message'])) {
        echo '<div class="message">' . htmlspecialchars($_SESSION['reset_message']) . '</div>';
        unset($_SESSION['reset_message']);
    }
    ?>

    <div class="main-container">
        <div class="form-wrapper">
            <div class="primary-section">
                <div class="about-section">
                    <p class="greet">Bem-vindo a</p>
                    <div class="logo">
                        <img src="./assets/NeoFinance--Logo.svg" alt="NeoFinance--Logo">
                        <p>Neo Finance</p>
                    </div>
                    <p class="about"></p>
                    <div class="pages-link">
                        <a href="#" id="open-privacy-modal" style="color: #fff; text-decoration: none;">Política de privacidade</a>
                    </div>
                </div>
            </div>
            <div class="secondary-section">
                <h2 id="form-title">Login</h2>
                <form id="login-form" method="post" action="../../config/login/login_.php">
                    <div class="input-field">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Insira seu Email" required autocomplete="off">
                    </div>
                    <div class="input-field">
                        <label for="password">Senha</label>
                        <div class="password-container">
                            <input type="password" id="password" name="password" placeholder="Insira sua Senha" required autocomplete="off">
                            <i class="far fa-eye" id="toggle-password"></i>
                        </div>
                    </div>

                    <div class="button-sec">
                        <button type="submit" class="signin-btn">Entrar</button>
                    </div>
                    <div class="forgot-password">
                        <a href="./esqueci_senha.php">Esqueceu a senha?</a>
                    </div>
                    <div class="signup-link">
                        <p>Não tem uma conta? <a href="./cadastro.php">Cadastre-se aqui</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="privacy-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Política de Privacidade</h2>
            <p><strong>1. Introdução</strong></p>
            <p>Bem-vindo à [Neo Finance]. A sua privacidade é importante para nós. Esta Política de Privacidade explica como coletamos, usamos, armazenamos e protegemos suas informações pessoais quando você usa nosso site e serviços. Ao acessar ou usar nosso site, você concorda com a coleta e uso de informações conforme descrito nesta política.</p>

            <p><strong>2. Informações que Coletamos</strong></p>
            <p><strong>2.1 Informações Pessoais:</strong> Coletamos informações pessoais que você nos fornece diretamente, como nome, e-mail e informações financeiras necessárias para o uso de nossos serviços.</p>
            <p><strong>2.2 Informações de Uso:</strong> Coletamos informações sobre sua interação com nosso site, como endereço IP, tipo de navegador, páginas visitadas e tempo gasto em cada página.</p>
            <p><strong>2.3 Cookies e Tecnologias Semelhantes:</strong> Utilizamos cookies e outras tecnologias semelhantes para melhorar sua experiência no site, analisar o tráfego e personalizar o conteúdo. Você pode ajustar as configurações de cookies em seu navegador a qualquer momento.</p>

            <p><strong>3. Uso das Informações</strong></p>
            <p><strong>3.1 Fornecimento de Serviços:</strong> Usamos suas informações pessoais para fornecer, manter e melhorar nossos serviços, incluindo o processamento de transações e a personalização de sua experiência.</p>
            <p><strong>3.2 Comunicação:</strong> Podemos usar suas informações para entrar em contato com você sobre atualizações, ofertas promocionais e outras informações relevantes. Você pode optar por não receber essas comunicações a qualquer momento.</p>
            <p><strong>3.3 Análise e Melhoria:</strong> Utilizamos informações de uso para analisar o desempenho do site e melhorar nossos serviços.</p>

            <p><strong>4. Compartilhamento de Informações</strong></p>
            <p><strong>4.1 Terceiros:</strong> Não compartilhamos suas informações pessoais com terceiros, exceto quando necessário para cumprir a lei, proteger nossos direitos ou fornecer nossos serviços.</p>
            <p><strong>4.2 Segurança:</strong> Adotamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não autorizado, alteração ou destruição.</p>

            <p><strong>5. Seus Direitos</strong></p>
            <p><strong>5.1 Acesso e Correção:</strong> Você tem o direito de acessar, corrigir ou excluir suas informações pessoais que mantemos. Para fazer isso, entre em contato conosco através das informações fornecidas abaixo.</p>
            <p><strong>5.2 Opt-Out:</strong> Você pode optar por não receber comunicações promocionais a qualquer momento, seguindo as instruções de cancelamento de inscrição incluídas em nossos e-mails.</p>

            <p><strong>6. Alterações nesta Política</strong></p>
            <p>Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre qualquer alteração significativa por meio de uma postagem em nosso site ou por e-mail. Recomendamos que você reveja esta política regularmente para se manter informado sobre como protegemos suas informações.</p>

            <p><strong>7. Contato</strong></p>
            <p>Se você tiver dúvidas sobre esta Política de Privacidade ou sobre nossas práticas de privacidade, entre em contato conosco:</p>
            <p>E-mail: [Seu e-mail]</p>
            <p>Endereço: [Seu endereço]</p>
            <p>Telefone: [Seu telefone]</p>
        </div>
    </div>

    <div id="reset-code-display" style="display:none; margin-top: 10px; color: red;"></div>

    <script>
        var modal = document.getElementById('privacy-modal');
        var openModalLink = document.getElementById('open-privacy-modal');
        var closeButton = document.getElementsByClassName('close')[0];

        openModalLink.onclick = function() {
            modal.style.display = 'block';
        }

        closeButton.onclick = function() {
            modal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }

        var passwordInput = document.getElementById('password');
        var togglePassword = document.getElementById('toggle-password');

        togglePassword.addEventListener('click', function() {
            // Verificar o tipo atual do campo de senha
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                togglePassword.classList.remove('fa-eye');
                togglePassword.classList.add('fa-eye-slash'); // Muda o ícone para o olho com barra
            } else {
                passwordInput.type = 'password';
                togglePassword.classList.remove('fa-eye-slash');
                togglePassword.classList.add('fa-eye'); // Volta o ícone de olho normal
            }
        });
    </script>
</body>

</html>