<?php
session_start();
include '../../config/database/conexao.php'; // conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Sanitização dos dados de entrada
    $username = trim($_POST['username']);
    $email = trim($_POST['signup-email']);
    $password = $_POST['signup-password'];
    $confirm_pass = $_POST['confirm-pass'];

    // Verificar se o nome de usuário já existe no banco de dados
    $query_username = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query_username);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['signup_message'] = "Nome de usuário já está em uso.";
        header('Location: ./cadastro.php');
        exit();
    }

    // Verificar se o email já existe no banco de dados
    $query_email = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($query_email);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['signup_message'] = "Email já está em uso.";
        header('Location: ./cadastro.php');
        exit();
    }

    // Verificar se a senha e a confirmação coincidem
    if ($password !== $confirm_pass) {
        $_SESSION['signup_message'] = "As senhas não coincidem.";
        header('Location: ./cadastro.php');
        exit();
    }

    // Inserção no banco de dados
    $password_hash = password_hash($password, PASSWORD_BCRYPT); // Criptografa a senha
    $insert_query = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)";

    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("sss", $username, $email, $password_hash);

    if ($stmt->execute()) {
        $_SESSION['signup_message'] = "Cadastro realizado com sucesso!";
        header('Location: ./login.php');
    } else {
        // Exibe o erro do MySQL se ocorrer falha
        $_SESSION['signup_message'] = "Erro ao cadastrar: " . $stmt->error;
        header('Location: ./cadastro.php');
    }

    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Cadastro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../../css/login/telaCadastro.css">
</head>

<body>
    <?php

    if (isset($_SESSION['signup_message'])) {
        echo '<div class="message success">' . htmlspecialchars($_SESSION['signup_message']) . '</div>';
        unset($_SESSION['signup_message']);
    }

    if (isset($_SESSION['login_message'])) {
        echo '<div class="message success">' . htmlspecialchars($_SESSION['login_message']) . '</div>';
        unset($_SESSION['login_message']);
    }

    if (isset($_SESSION['reset_message'])) {
        echo '<div class="message error">' . htmlspecialchars($_SESSION['reset_message']) . '</div>';
        unset($_SESSION['reset_message']);
    }
    ?>
    <div class="main-container">
        <div class="form-wrapper">
            <div class="primary-section">
                <div class="about-section">
                    <p class="greet">Bem-vindo a</p>
                    <div class="logo">
                        <img src="../../assets/img/neofinance--logo.svg" alt="NeoFinance--Logo">
                        <p>Neo Finance</p>
                    </div>
                    <p class="about"></p>
                    <div class="pages-link">
                        <a href="#" id="open-privacy-modal" style="color: #fff; text-decoration: none;">Política de privacidade</a>
                        <!-- Link para abrir o modal de termos -->
                    </div>
                </div>
            </div>
            <div class="secondary-section">
                <h2 id="form-title">Cadastre-se</h2>
                <form id="signup-form" method="POST" action="./cadastro.php">
                    <div class="input-field">
                        <label for="signup-username">Nome de Usuário</label>
                        <input type="text" id="signup-username" name="username" placeholder="Insira seu Nome de Usuário" required>
                    </div>
                    <div class="input-field">
                        <label for="signup-email">Email</label>
                        <input type="email" id="signup-email" name="signup-email" placeholder="Insira seu Email" required>
                    </div>
                    <div class="input-field">
                        <label for="signup-password">Senha</label>
                        <div class="password-container">
                            <input type="password" id="signup-password" name="signup-password" placeholder="Crie uma Senha" required>
                            <i class="fas fa-eye" id="togglePassword" style="cursor: pointer;"></i>
                        </div>
                    </div>
                    <div class="input-field">
                        <label for="confirm-pass">Confirme a Senha</label>
                        <div class="password-container">
                            <input type="password" id="confirm-pass" name="confirm-pass" placeholder="Digite a Senha Novamente" required>
                            <i class="fas fa-eye" id="toggleConfirmPassword" style="cursor: pointer;"></i>
                        </div>
                    </div>

                    <div class="agree-sec">
                        <input type="checkbox" id="terms" name="terms" required>
                        <label for="terms">Eu concordo com os <a href="#" id="open-terms-modal">Termos e condições</a></label>
                    </div>
                    <div class="button-sec">
                        <button type="submit" class="signup-btn">Se inscrever</button>
                    </div>
                    <div class="signin-link">
                        <p>Já tem uma conta? <a href="./login.php">Voltar para Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal de Termos e Condições -->
    <div id="terms-modal" class="modal">
        <div class="modal-content">
            <span class="close" data-modal="terms-modal">&times;</span>
            <h2>Termos e Condições</h2>
            <p><strong>1. Aceitação dos Termos</strong></p>
            <p>Ao acessar e usar o site [Neo finance], você concorda com estes Termos e Condições e com nossa Política de Privacidade. Se você não concordar com estes termos, por favor, não use nosso site.</p>

            <p><strong>2. Modificações dos Termos</strong></p>
            <p>Reservamo-nos o direito de modificar estes Termos e Condições a qualquer momento. Quaisquer alterações serão publicadas em nosso site. É sua responsabilidade revisar regularmente os Termos e Condições para estar ciente de quaisquer alterações.</p>

            <p><strong>3. Uso do Site</strong></p>
            <p>Você concorda em usar nosso site apenas para fins legais e de acordo com todas as leis e regulamentos aplicáveis. É proibido usar o site para qualquer atividade que seja ilegal ou que possa causar danos ao site ou a terceiros.</p>

            <p><strong>4. Registro e Conta</strong></p>
            <p>Para acessar certas funcionalidades do site, você pode ser solicitado a criar uma conta. Você concorda em fornecer informações verdadeiras, precisas e completas durante o processo de registro e em atualizar essas informações para mantê-las precisas.</p>

            <p><strong>5. Responsabilidade</strong></p>
            <p>O [Nome do Site] não se responsabiliza por quaisquer danos diretos, indiretos, incidentais ou consequenciais resultantes do uso ou da incapacidade de usar o site. Isto inclui, mas não se limita a, danos por perda de lucros, interrupção de negócios ou perda de informações.</p>

            <p><strong>6. Propriedade Intelectual</strong></p>
            <p>Todo o conteúdo do site, incluindo textos, gráficos, logotipos, ícones e software, é de propriedade do [Nome do Site] ou de seus licenciadores e está protegido por leis de direitos autorais e outras leis de propriedade intelectual.</p>

            <p><strong>7. Links para Sites de Terceiros</strong></p>
            <p>Nosso site pode conter links para sites de terceiros. Não somos responsáveis pelo conteúdo, políticas de privacidade ou práticas desses sites. O acesso a sites de terceiros é por sua conta e risco.</p>

            <p><strong>8. Limitação de Responsabilidade</strong></p>
            <p>Na máxima extensão permitida por lei, a responsabilidade do [Neo Finance] por qualquer reclamação relacionada ao uso do site é limitada ao valor que você pagou pelo uso do site ou serviço, se aplicável.</p>

            <p><strong>9. Lei Aplicável</strong></p>
            <p>Estes Termos e Condições são regidos pelas leis do [Brasil/Bahia]. Qualquer disputa relacionada a estes termos será resolvida nos tribunais competentes do [Brasil/Bahia].</p>

            <p><strong>10. Contato</strong></p>
            <p>Se você tiver dúvidas sobre estes Termos e Condições, entre em contato conosco:</p>
            <p>E-mail: [neo.finance.contato@gmail.com]</p>
            <p>Endereço: [Seu endereço]</p>
            <p>Telefone: [Seu telefone]</p>
        </div>
    </div>

    <!-- Modal de Política de Privacidade -->
    <div id="privacy-modal" class="modal">
        <div class="modal-content">
            <span class="close" data-modal="privacy-modal">&times;</span>
            <h2>Política de Privacidade</h2>
            <p><strong>1. Introdução</strong></p>
            <p>Bem-vindo à [Neo Finance]. A sua privacidade é importante para nós. Esta Política de Privacidade explica como coletamos, usamos, armazenamos e protegemos suas informações pessoais quando você usa nosso site e serviços. Ao acessar ou usar nosso site, você concorda com a coleta e uso de informações conforme descrito nesta política.</p>

            <p><strong>2. Informações que Coletamos</strong></p>
            <p><strong>2.1 Informações Pessoais:</strong> Coletamos informações pessoais que você nos fornece diretamente, como nome, e-mail e informações financeiras necessárias para o uso de nossos serviços.</p>
            <p><strong>2.2 Informações de Uso:</strong> Coletamos informações sobre sua interação com nosso site, como endereço IP, tipo de navegador, páginas visitadas e tempo gasto em cada página.</p>
            <p><strong>2.3 Cookies e Tecnologias Semelhantes:</strong> Utilizamos cookies e outras tecnologias semelhantes para melhorar sua experiência no site, analisar o tráfego e personalizar o conteúdo. Você pode ajustar as configurações de cookies em seu navegador a qualquer momento.</p>

            <p><strong>3. Uso das Informações</strong></p>
            <p><strong>3.1 Fornecimento de Serviços:</strong> Usamos suas informações pessoais para fornecer, manter e melhorar nossos serviços, incluindo o processamento de transações e a personalização de sua experiência.</p>
            <p><strong>3.2 Comunicação:</strong> Podemos usar suas informações para entrar em contato com você sobre atualizações, ofertas promocionais e outras informações relevantes. Você pode optar por não receber essas comunicações a qualquer momento.</p>
            <p><strong>3.3 Análise e Melhoria:</strong> Utilizamos informações de uso para analisar o desempenho do site e melhorar nossos serviços.</p>

            <p><strong>4. Compartilhamento de Informações</strong></p>
            <p><strong>4.1 Terceiros:</strong> Não compartilhamos suas informações pessoais com terceiros, exceto quando necessário para cumprir a lei, proteger nossos direitos ou fornecer nossos serviços.</p>
            <p><strong>4.2 Segurança:</strong> Adotamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não autorizado, alteração ou destruição.</p>

            <p><strong>5. Seus Direitos</strong></p>
            <p><strong>5.1 Acesso e Correção:</strong> Você tem o direito de acessar, corrigir ou excluir suas informações pessoais que mantemos. Para fazer isso, entre em contato conosco através das informações fornecidas abaixo.</p>
            <p><strong>5.2 Opt-Out:</strong> Você pode optar por não receber comunicações promocionais a qualquer momento, seguindo as instruções de cancelamento de inscrição incluídas em nossos e-mails.</p>

            <p><strong>6. Alterações nesta Política</strong></p>
            <p>Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre qualquer alteração significativa por meio de uma postagem em nosso site ou por e-mail. Recomendamos que você reveja esta política regularmente para se manter informado sobre como protegemos suas informações.</p>

            <p><strong>7. Contato</strong></p>
            <p>Se você tiver dúvidas sobre esta Política de Privacidade ou sobre nossas práticas de privacidade, entre em contato conosco:</p>
            <p>E-mail: [Seu e-mail]</p>
            <p>Endereço: [Senai camaçari]</p>
            <p>Telefone: [(71) 3454-1000]</p>
        </div>
    </div>


    <div id="reset-code-display" style="display:none; margin-top: 10px; color: red;"></div>

    <script>
        // Function to handle opening and closing of modals
        function handleModal(modalId, action) {
            var modal = document.getElementById(modalId);
            modal.style.display = action === 'open' ? 'block' : 'none';
        }

        // Open modal functions
        document.getElementById('open-terms-modal').onclick = function(event) {
            event.preventDefault(); // Prevent default link behavior
            handleModal('terms-modal', 'open');
        }

        document.getElementById('open-privacy-modal').onclick = function(event) {
            event.preventDefault(); // Prevent default link behavior
            handleModal('privacy-modal', 'open');
        }

        // Close modal functions
        var closeButtons = document.getElementsByClassName('close');
        for (var i = 0; i < closeButtons.length; i++) {
            closeButtons[i].onclick = function() {
                handleModal(this.getAttribute('data-modal'), 'close');
            }
        }

        // Close modal when clicking outside of the modal
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                handleModal(event.target.id, 'close');
            }
        }
        // Função para alternar a visibilidade da senha
        document.getElementById('togglePassword').addEventListener('click', function(e) {
            const password = document.getElementById('signup-password');
            const icon = e.target;
            // Alternar o tipo de input
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            // Alternar o ícone
            icon.classList.toggle('fa-eye-slash');
        });

        document.getElementById('toggleConfirmPassword').addEventListener('click', function(e) {
            const confirmPassword = document.getElementById('confirm-pass');
            const icon = e.target;
            // Alternar o tipo de input
            const type = confirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
            confirmPassword.setAttribute('type', type);
            // Alternar o ícone
            icon.classList.toggle('fa-eye-slash');
        });
    </script>
</body>

</html>