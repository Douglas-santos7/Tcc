<?php
session_start();
require '../../vendor/autoload.php';
include '../../config/database/conexao.php'; // conexão com o banco de dados

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Inicializa a mensagem de erro
$error_message = '';

// Verifica se a requisição foi feita via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifica se a variável de sessão está definida
    if (isset($_SESSION['reset_email'])) {
        $email = $_SESSION['reset_email'];
        $resetCode = $_POST['verification_code']; // Nome da chave corrigido

        // Verifica se o código de redefinição é válido
        $stmt = $conn->prepare("
            SELECT pr.user_id
            FROM password_resets pr
            JOIN users u ON pr.user_id = u.id
            WHERE u.email = ? AND pr.reset_code = ?
        ");
        $stmt->bind_param("ss", $email, $resetCode);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Código válido, redirecionar para a página de redefinição de senha
            $_SESSION['reset_email'] = $email;
            header("Location: ./reset_senha.php");
            exit();
        } else {
            // Código inválido, definir mensagem de erro
            $_SESSION['error_message'] = 'Código de redefinição inválido!';
        }

        $stmt->close();
    } else {
        // Se a variável de sessão não estiver definida, redirecionar para a página de esqueci a senha
        header("Location: ./esqueci_senha.php");
        exit();
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Código</title>
    <link rel="stylesheet" href="../../css/login/telaCadastro.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
</head>
<body>
    <div class="main-container">
        <div class="image-container">
            <div class="carousel">
                <div class="carousel-images">
                    <img src="../../assets/img/carrosel--logjn/1.jpg" alt="">
                    <img src="../../assets/img/carrosel--logjn/2.jpg" alt="">
                    <img src="../../assets/img/carrosel--logjn/1.jpg" alt="">
                    <video src="../../assets/img/carrosel--logjn/Iphon.mp4" loop muted autoplay></video>
                </div>
                <div class="carousel-dots">
                    <span class="dot" onclick="currentSlide(1)"></span>
                    <span class="dot" onclick="currentSlide(2)"></span>
                    <span class="dot" onclick="currentSlide(3)"></span>
                    <span class="dot" onclick="currentSlide(4)"></span>
                </div>
            </div>
        </div>
        <div class="form-container">
            <div class="logo-container">
                <img src="../../assets/img/neofinance--logo.svg" alt="Logo"> <!-- Insira o caminho para a sua logo -->
            </div>
            <div class="signup-form">
                <div class="title">Verificar Código</div>
                <form method="POST" action="./codigo_verificacao.php">
                    <div class="field">
                        <input type="text" id="verification-code" name="verification_code" placeholder=" " required>
                        <label for="verification-code">Código de Verificação</label>
                        <i class="fa fa-key"></i>
                    </div>
                    <button type="submit" class="login-btn">Verificar Código</button>
                </form>
                <div class="messages <?php echo isset($_SESSION['error_message']) ? 'show' : ''; ?>">
                    <p class="error"><?php echo isset($_SESSION['error_message']) ? htmlspecialchars($_SESSION['error_message']) : ''; ?></p>
                </div>
                <?php
                if (isset($_SESSION['error_message'])) {
                    unset($_SESSION['error_message']); 
                }
                ?>
                <div class="bottom">
                    <span>Não recebeu o código?&nbsp;<a href="./esqueci_senha.php">Reenviar Código</a></span>
                </div>
            </div>
        </div>
    </div>

    <script>
         let slideIndex = 1;
        showSlides(slideIndex);

        // Mudar o slide a cada 10 segundos
        setInterval(() => {
            showSlides(slideIndex += 1);
        }, 10000);

        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            const slides = document.querySelectorAll('.carousel-images img, .carousel-images video');
            const dots = document.querySelectorAll('.dot');

            if (n > slides.length) { slideIndex = 1 }
            if (n < 1) { slideIndex = slides.length }

            slides.forEach((slide, index) => {
                slide.style.display = (index + 1 === slideIndex) ? 'block' : 'none';
                // Reproduzir o vídeo ativo
                if (index + 1 === slideIndex && slide.tagName === 'VIDEO') {
                    slide.play();
                } else if (slide.tagName === 'VIDEO') {
                    slide.pause();
                }
            });

            dots.forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === slideIndex);
            });
        }
    </script>
</body>
</html>
