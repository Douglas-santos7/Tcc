<?php
session_start();
include '../../database/conexao.php'; // Conexão com o banco de dados

$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['nome'])) {
    $nome = $input['nome'];
    $icone = $input['icone']; // Inclua a coleta do ícone

    // Verifica se a categoria já existe
    $sql = "SELECT id FROM categorias WHERE nome = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $nome);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Categoria já existe']);
        exit();
    }

    // Insere a nova categoria
    $sql = "INSERT INTO categorias (nome, icone) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $nome, $icone);

    if ($stmt->execute()) {
        $id = $stmt->insert_id; // ID da nova categoria
        echo json_encode(['status' => 'success', 'id' => $id]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar categoria']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Dados incompletos']);
}
?>
