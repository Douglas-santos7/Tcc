<?php
// Arquivo: funcoes.php

// Função para calcular os dias restantes até o vencimento
function calcularDiasRestantes($dataVencimento)
{
    $hoje = new DateTime();
    $vencimento = new DateTime($dataVencimento);
    $interval = $hoje->diff($vencimento);

    if ($interval->days == 0 && $interval->invert == 0) {
        return "Vence hoje";
    } elseif ($interval->invert == 1) {
        return "Vence Hoje";
    } else {
        return $interval->days . " dias restantes";
    }
}
