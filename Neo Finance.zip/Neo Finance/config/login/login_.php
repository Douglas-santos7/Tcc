<?php
session_start();

include '../../config/database/conexao.php'; // conexão com o banco de dados


if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Inicialize o contador de tentativas de login
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

// Processa o formulário de login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Verifica se o email existe no banco de dados
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Se o email for encontrado, verifica a senha
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $stored_password_hash = $user['password_hash']; // Hash da senha armazenada no banco

        // Verifica se a senha fornecida corresponde ao hash armazenado
        if (password_verify($password, $stored_password_hash)) {
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['login_attempts'] = 0; // Resetar tentativas após sucesso
            header("Location: ../../views/home.php"); // Redireciona para o dashboard
            exit();
        } else {
            // Senha incorreta
            $_SESSION['login_attempts']++;
            if ($_SESSION['login_attempts'] >= 3) {
                $_SESSION['reset_message'] = 'Você errou a senha 3 vezes. Redefina sua senha.';
                header("Location: ../../views/login/esqueci_senha.php"); // Redireciona para redefinição de senha
                exit();
            } else {
                $_SESSION['login_message'] = 'Senha incorreta! Tentativa ' . $_SESSION['login_attempts'] . ' de 3.';
            }
        }
    } else {
        // Email não encontrado
        $_SESSION['login_message'] = 'Email não encontrado!';
    }

    // Fecha a consulta
    $stmt->close();
    // Redireciona de volta para a tela de login com a mensagem de erro
    header("Location: ../../views/login/login.php");
    exit();
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
