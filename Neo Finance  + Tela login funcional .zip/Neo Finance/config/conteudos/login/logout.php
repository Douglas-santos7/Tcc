<?php
session_start(); // Inicia a sessão

// Limpa a sessão
$_SESSION = array();
session_destroy(); // Destroi a sessão

// Remove o cookie de lembrete, se existir
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, "/");
}

// Redireciona para a página de login
header("Location: ../../../views/login/login.php"); // Atualize este caminho se necessário
exit();
