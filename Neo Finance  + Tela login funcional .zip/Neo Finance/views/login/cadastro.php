<?php
session_start();
include '../../config/database/conexao.php'; // conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitização dos dados de entrada
    $username = trim($_POST['username']);
    $email = trim($_POST['email']); // changed to match the form name
    $password = $_POST['password']; // Ensure to match the form name
    $confirm_pass = $_POST['confirm_password']; // Ensure to match the form name

    // Verificar se o nome de usuário já existe no banco de dados
    $query_username = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query_username);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['signup_message'] = "Nome de usuário já está em uso.";
        header('Location: ./cadastro.php');
        exit();
    }

    // Verificar se o email já existe no banco de dados
    $query_email = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($query_email);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['signup_message'] = "Email já está em uso.";
        header('Location: ./cadastro.php');
        exit();
    }

    // Verificar se a senha e a confirmação coincidem
    if ($password !== $confirm_pass) {
        $_SESSION['signup_message'] = "As senhas não coincidem.";
        header('Location: ./cadastro.php');
        exit();
    }

    // Inserção no banco de dados
    $password_hash = password_hash($password, PASSWORD_BCRYPT); // Criptografa a senha
    $insert_query = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)";

    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("sss", $username, $email, $password_hash);

    if ($stmt->execute()) {
        $_SESSION['signup_message'] = "Cadastro realizado com sucesso!";
        header('Location: ./login.php');
    } else {
        // Exibe o erro do MySQL se ocorrer falha
        $_SESSION['signup_message'] = "Erro ao cadastrar: " . $stmt->error;
        header('Location: ./cadastro.php');
    }

    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="../../css/login/telaCadastro.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
    <link href="https://fonts.googleapis.com/css2?family=Kodchasan&display=swap" rel="stylesheet">
</head>

<body>
    <div class="main-container">
        <div class="image-container">
            <div class="carousel">
                <div class="carousel-images">
                    <img src="../../assets/img/carrosel--logjn/1.jpg" alt="">
                    <img src="../../assets/img/carrosel--logjn/2.jpg" alt="">
                    <img src="../../assets/img/carrosel--logjn/1.jpg" alt="">
                    <img src="../../assets/img/carrosel--logjn/2.jpg" alt="">
                </div>
                <!-- <div class="carousel-dots">
                        <span class="dot" onclick="currentSlide(1)"></span>
                        <span class="dot" onclick="currentSlide(2)"></span>
                        <span class="dot" onclick="currentSlide(3)"></span>
                        <span class="dot" onclick="currentSlide(4)"></span>
                    </div> -->
            </div>
        </div>
        <div class="form-container">
            <div class="logo-container">
                <img src="../../assets/img/neofinance--logo.svg" alt="Logo">
            </div>
            <div class="signup-form">
                <div class="title">CADASTRO</div>
                <p class="cadastro-text">Seja bem vindo a Neo finance, Efetue o cadastro</p>
                <form method="POST" action="cadastro.php"> <!-- Changed to cadastro.php -->
                    <div class="field">
                        <input type="text" id="name" name="username" placeholder=" " required>
                        <label for="name">Nome</label>
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="field">
                        <input type="email" id="user-email" name="email" placeholder=" " required>
                        <label for="user-email">Email</label>
                        <i class="fa fa-envelope"></i>
                    </div>
                    <div class="field">
                        <input type="password" id="signup-pass" name="password" required placeholder=" " autocomplete="on">
                        <label for="signup-pass">Senha</label>
                        <i class="fa fa-eye toggle-password" onclick="togglePasswordVisibility('signup-pass', this)"></i>
                        <i class="fa fa-lock"></i>
                    </div>
                    <div class="field">
                        <input type="password" id="confirm-pass" name="confirm_password" required placeholder=" " autocomplete="off">
                        <label for="confirm-pass">Confirme a Senha</label>
                        <i class="fa fa-lock"></i>
                        <i class="fa fa-eye toggle-password" onclick="togglePasswordVisibility('confirm-pass', this)"></i>
                    </div>
                    <section>
                        <label for="agree">
                            <input type="checkbox" id="agree" required> Eu concordo com &nbsp;<a href="#" id="terms-link">Termos e Condições</a>
                        </label>
                    </section>
                    <button type="submit" class="login-btn">Registrar</button>
                </form>

                <div class="message">
                    <?php
                    if (isset($_SESSION['signup_message'])) { // Use signup_message here
                        echo '<p style="color: red;">' . $_SESSION['signup_message'] . '</p>';
                        unset($_SESSION['signup_message']);
                    }
                    ?>
                </div>

                <div class="bottom">
                    <span>Já Registrado?&nbsp;<a href="login.php">Login</a></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para Termos e Condições -->
    <div id="termsModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Termos e Condições</h2>
            <p>1. Aceitação dos Termos</p>
            <p>Ao acessar e usar o site <strong>Neo finance</strong>, você concorda em cumprir e estar sujeito a estes Termos e Condições. Se você não concordar com estes termos, não deve usar o Serviço.</p>

            <p>2. Descrição do Serviço</p>
            <p><strong>Neo finance</strong> oferece um serviço de controle de finanças pessoais que permite aos usuários monitorar suas receitas, despesas e investimentos. O Serviço é destinado apenas para fins informativos.</p>

            <p>3. Uso do Serviço</p>
            <p>Você concorda em usar o Serviço de forma responsável e em conformidade com todas as leis e regulamentos aplicáveis.</p>

            <p>4. Limitação de Responsabilidade</p>
            <p><strong>Neo finance</strong> não será responsável por quaisquer danos diretos, indiretos, incidentais, especiais ou consequenciais decorrentes do uso ou da incapacidade de uso do Serviço.</p>

            <p>5. Alterações aos Termos</p>
            <p>Reservamo-nos o direito de modificar estes Termos a qualquer momento. As alterações entrarão em vigor assim que publicadas no site.</p>

            <p>Data de Vigência: 27 de setembro de 2024</p>
        </div>
    </div>

    <script>
        let slideIndex = 1;
        showSlides(slideIndex);

        // Mudar o slide a cada 3 segundos
        setInterval(() => {
            showSlides(slideIndex += 1);
        }, 10000); // 3000 milissegundos = 3 segundos

        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            const slides = document.querySelectorAll('.carousel-images img, .carousel-images video');
            const dots = document.querySelectorAll('.dot');

            if (n > slides.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = slides.length
            }

            slides.forEach((slide, index) => {
                slide.style.display = (index + 1 === slideIndex) ? 'block' : 'none';
                // Reproduzir o vídeo ativo
                if (index + 1 === slideIndex && slide.tagName === 'VIDEO') {
                    slide.play();
                } else if (slide.tagName === 'VIDEO') {
                    slide.pause();
                }
            });

            dots.forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === slideIndex);
            });
        }

        function togglePasswordVisibility(inputId, eyeIcon) {
            const inputField = document.getElementById(inputId);
            const isPassword = inputField.type === 'password';

            inputField.type = isPassword ? 'text' : 'password';
            eyeIcon.classList.toggle('fa-eye-slash', !isPassword);
        }

        // Modal para Termos e Condições
        const modal = document.getElementById("termsModal");
        const termsLink = document.getElementById("terms-link");

        termsLink.onclick = function(event) {
            event.preventDefault();
            modal.style.display = "block";
        }

        function closeModal() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>

</html>