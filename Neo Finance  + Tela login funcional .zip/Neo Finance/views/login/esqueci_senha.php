<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../../config/database/conexao.php'; // conexão com o banco de dados

require '../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['forgot-email'];

    // Verificação se o email existe no banco de dados
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $user_id = $user['id'];
        $username = $user['username']; // Capturar o nome de usuário

        // Gerar um código de redefinição de senha
        $resetCode = mt_rand(100000, 999999);

        // Salvar o código de redefinição no banco de dados
        $stmt = $conn->prepare("INSERT INTO password_resets (user_id, reset_code, created_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE reset_code = ?, created_at = NOW()");
        $stmt->bind_param("iss", $user_id, $resetCode, $resetCode);
        $stmt->execute();

        // Configuração do PHPMailer
        $mail = new PHPMailer(true);

        try {
            // Configurações do servidor SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'neo.finance.contato@gmail.com';
            $mail->Password = 'txht dkee nmdi msvz'; // Use a senha de aplicativo aqui
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->CharSet = 'UTF-8';

            // Remetente e destinatário
            $mail->setFrom('neo.finance.contato@gmail.com', 'Neo Finance');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Código de Redefinição de Senha';

            // Corpo do email com o nome de usuário
            $mail->Body    = 'Olá ' . htmlspecialchars($username) . ',<br><br>Você solicitou a redefinição de sua senha. Aqui está o código de redefinição que você precisará para criar uma nova senha:<br><br><b>' . $resetCode . '</b><br><br>Se você não solicitou esta mudança, por favor, ignore esta mensagem.<br><br>Atenciosamente,<br>Neo Finance';
            $mail->AltBody = 'Olá ' . htmlspecialchars($username) . ",\n\nVocê solicitou a redefinição de sua senha. Aqui está o código de redefinição que você precisará para criar uma nova senha:\n\n" . $resetCode . "\n\nSe você não solicitou esta mudança, por favor, ignore esta mensagem.\n\nAtenciosamente,\nNeo Finance";

            // Enviar o email
            $mail->send();

            // Armazenar mensagem de sucesso na sessão
            $_SESSION['reset_message'] = 'Código de redefinição enviado para o seu email.';

            // Redirecionar para a página de verificação de código
            $_SESSION['reset_email'] = $email;
            header("Location: ./codigo_verificacao.php");
            exit();
        } catch (Exception $e) {
            echo "Erro ao enviar email: {$mail->ErrorInfo}";
        }
    } else {
        echo 'Email não encontrado!';
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../../css/login/telaLogin.css">
</head>

<body>
    <?php
    if (isset($_SESSION['reset_message'])) {
        echo '<div class="message">' . htmlspecialchars($_SESSION['reset_message']) . '</div>';
        unset($_SESSION['reset_message']);
    }
    ?>


    <div class="main-container">
        <div class="form-wrapper">
            <div class="primary-section">
                <div class="about-section">
                    <p class="greet">Bem-vindo a</p>
                    <div class="logo">
                        <img src="./assets/NeoFinance--Logo.svg" alt="NeoFinance--Logo">
                        <p>Neo Finance</p>
                    </div>
                    <p class="about"></p>
                    <div class="pages-link">
                        <a href="#" id="open-privacy-modal" style="color: #fff; text-decoration: none;">Política de privacidade</a>
                        <a href="#">Sobre nós</a>
                    </div>
                </div>
            </div>
            <div class="secondary-section">
                <h2 id="form-title">Recuperar Senha</h2>
                <form id="forgot-password-form" method="post" action="./esqueci_senha.php">
                    <div class="input-field">
                        <label for="forgot-email">Email</label>
                        <input type="email" id="forgot-email" name="forgot-email" placeholder="Insira seu Email" required autocomplete="off">
                    </div>
                    <div class="button-sec">
                        <button type="submit" class="forgot-password-btn">Enviar código de redefinição</button>
                    </div>
                    <div class="back-to-login">
                        <p><a href="./login.php">Voltar para Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="privacy-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Política de Privacidade</h2>
            <p><strong>1. Introdução</strong></p>
            <p>Bem-vindo à [Neo Finance]. A sua privacidade é importante para nós. Esta Política de Privacidade explica como coletamos, usamos, armazenamos e protegemos suas informações pessoais quando você usa nosso site e serviços. Ao acessar ou usar nosso site, você concorda com a coleta e uso de informações conforme descrito nesta política.</p>

            <p><strong>2. Informações que Coletamos</strong></p>
            <p><strong>2.1 Informações Pessoais:</strong> Coletamos informações pessoais que você nos fornece diretamente, como nome, e-mail e informações financeiras necessárias para o uso de nossos serviços.</p>
            <p><strong>2.2 Informações de Uso:</strong> Coletamos informações sobre sua interação com nosso site, como endereço IP, tipo de navegador, páginas visitadas e tempo gasto em cada página.</p>
            <p><strong>2.3 Cookies e Tecnologias Semelhantes:</strong> Utilizamos cookies e outras tecnologias semelhantes para melhorar sua experiência no site, analisar o tráfego e personalizar o conteúdo. Você pode ajustar as configurações de cookies em seu navegador a qualquer momento.</p>

            <p><strong>3. Uso das Informações</strong></p>
            <p><strong>3.1 Fornecimento de Serviços:</strong> Usamos suas informações pessoais para fornecer, manter e melhorar nossos serviços, incluindo o processamento de transações e a personalização de sua experiência.</p>
            <p><strong>3.2 Comunicação:</strong> Podemos usar suas informações para entrar em contato com você sobre atualizações, ofertas promocionais e outras informações relevantes. Você pode optar por não receber essas comunicações a qualquer momento.</p>
            <p><strong>3.3 Análise e Melhoria:</strong> Utilizamos informações de uso para analisar o desempenho do site e melhorar nossos serviços.</p>

            <p><strong>4. Compartilhamento de Informações</strong></p>
            <p><strong>4.1 Terceiros:</strong> Não compartilhamos suas informações pessoais com terceiros, exceto quando necessário para cumprir a lei, proteger nossos direitos ou fornecer nossos serviços.</p>
            <p><strong>4.2 Segurança:</strong> Adotamos medidas de segurança adequadas para proteger suas informações pessoais contra acesso não autorizado, alteração ou destruição.</p>

            <p><strong>5. Seus Direitos</strong></p>
            <p><strong>5.1 Acesso e Correção:</strong> Você tem o direito de acessar, corrigir ou excluir suas informações pessoais que mantemos. Para fazer isso, entre em contato conosco através das informações fornecidas abaixo.</p>
            <p><strong>5.2 Opt-Out:</strong> Você pode optar por não receber comunicações promocionais a qualquer momento, seguindo as instruções de cancelamento de inscrição incluídas em nossos e-mails.</p>

            <p><strong>6. Alterações nesta Política</strong></p>
            <p>Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre qualquer alteração significativa por meio de uma postagem em nosso site ou por e-mail. Recomendamos que você reveja esta política regularmente para se manter informado sobre como protegemos suas informações.</p>

            <p><strong>7. Contato</strong></p>
            <p>Se você tiver dúvidas sobre esta Política de Privacidade ou sobre nossas práticas de privacidade, entre em contato conosco:</p>
            <p>E-mail: [Seu e-mail]</p>
            <p>Endereço: [Seu endereço]</p>
            <p>Telefone: [Seu telefone]</p>
        </div>
    </div>

    <div id="reset-code-display" style="display:none; margin-top: 10px; color: red;"></div>

    <script>
        var modal = document.getElementById('privacy-modal');
        var openModalLink = document.getElementById('open-privacy-modal');
        var closeButton = document.getElementsByClassName('close')[0];

        openModalLink.onclick = function() {
            modal.style.display = 'block';
        }

        closeButton.onclick = function() {
            modal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>

</html>